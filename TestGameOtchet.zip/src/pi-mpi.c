#include <SFML/Graphics.hpp>
#include <ctime>
#include <iostream>
using namespace std;
using namespace sf;
int ground = 375; //Координаты на которых игрок перестанет падать
class Object {
public:
    Sprite game, settings, exit, about, DinoMenu, back, Exit_Text, Continue, pause, classic, hard, ys;
};
class Boolean {
public:
    bool menu = true, setting = false, start = false, pause = false, classic = true, hard = false, gameover = false, about = false;
};
class Player {
public:
    double dx, dy;
    FloatRect rect;
    bool onGround;
    Sprite sprite;
    double curFrame;
    int a;
    int &ra = a;
    Player(Texture& image) {
        sprite.setTexture(image);
        sprite.setTextureRect(IntRect(0, 0, 90, 95));

        dx = dy = 0;
        curFrame = 0;
        a = 0;
    }
    void update(double time) {
        rect.left += dx * time;
        if (!onGround)
            dy = dy + 0.0005 * time;
        rect.top += dy * time;
        if (rect.left == 0)
            rect.left = 100;
        if (rect.top == 0)
            rect.top = 375;
        onGround = false;
        if (rect.top > ground) {
            onGround = true;
            rect.top = ground;
            dy = 0;
        }
        if (dy == 0) {
            if (a == 0) {
                curFrame += 0.0003;
                if (curFrame > 1 && curFrame < 1.95)
                    curFrame = 1.95;
                if (curFrame > 2)
                    curFrame -= 2;
            }
            else if (a == 1) {
                if (curFrame < 2)
                    curFrame = 2;
                curFrame += 0.003;
                if (curFrame > 4)
                    curFrame -= 2;
            }
            else if (a == 2)
                curFrame = 4;

            sprite.setTextureRect(IntRect(90 * int(curFrame), 0, 90, 95));
        }
        sprite.setPosition(rect.left, rect.top);
        dx = 0;
    }
};
int main()
{
    RenderWindow window(VideoMode(1000, 500), "Test_Dino_Alpha");
    Object o;
    Boolean bb;
    Texture game, settings, exit, about, DinoMenu, back;
    game.loadFromFile("../texture/TestDino/game.png");
    settings.loadFromFile("../texture/TestDino/settings.png");
    exit.loadFromFile("../texture/TestDino/exit.png");
    about.loadFromFile("../texture/TestDino/about.png");
    DinoMenu.loadFromFile("../texture/TestDino/DinoMenu.png");
    back.loadFromFile("../texture/TestDino/exit.png");
    o.DinoMenu.setTexture(DinoMenu);
    o.DinoMenu.scale(0.03, 0.03);
    o.DinoMenu.setPosition(435, 100);
    o.game.setTexture(game);
    o.game.scale(0.3, 0.2);
    o.game.setPosition(470, 250);
    o.settings.setTexture(settings);
    o.settings.scale(0.3, 0.2);
    o.settings.setPosition(450, 300);
    o.back.setTexture(back);
    o.back.scale(0.2, 0.2);
    o.exit.setTexture(exit);
    o.exit.scale(0.2, 0.2);
    o.exit.setPosition(870, 40);
    o.about.setTexture(about);
    o.about.scale(0.2, 0.2);
    o.about.setPosition(830, 40);
    Texture Exit_Text, Continue, pause;
    Exit_Text.loadFromFile("../texture/TestDino/Exit_Text.png");
    Continue.loadFromFile("../texture/TestDino/Continue.png");
    pause.loadFromFile("../texture/TestDino/Pause.png");
    o.Exit_Text.setTexture(Exit_Text);
    o.Exit_Text.scale(0.3, 0.2);
    o.Exit_Text.setPosition(470, 150);
    o.Continue.setTexture(Continue);
    o.Continue.scale(0.3, 0.2);
    o.Continue.setPosition(440, 100);
    o.pause.setTexture(pause);
    o.pause.scale(0.3, 0.2);
    o.pause.setPosition(80, 40);
    Texture classic, hard, ys;
    classic.loadFromFile("../texture/TestDino/classic.png");
    hard.loadFromFile("../texture/TestDino/hard.png");
    ys.loadFromFile("../texture/TestDino/YS.png");
    o.ys.setTexture(ys);
    o.ys.scale(0.3, 0.2);
    o.ys.setPosition(350, 150);
    o.classic.setTexture(classic);
    o.classic.scale(0.3, 0.2);
    o.classic.setPosition(370, 250);
    o.hard.setTexture(hard);
    o.hard.scale(0.3, 0.2);
    o.hard.setPosition(570, 250);
    Texture Cloud;
    Cloud.loadFromFile("../texture/TestDino/Cloud.png");
    Sprite C(Cloud);
    C.scale(1, 1);
    C.setPosition(1000, 250);
    Texture lg;
    lg.loadFromFile("F:/texture/TestDino/Land.png");
    Sprite land(lg);
    land.scale(0.42, 1);
    land.setPosition(0, 450);
    Texture Din;
    Din.loadFromFile("F:/texture/TestDino/Dino.png");
    Player Dino(Din);
    Texture Cact[6];
    Sprite Cactus[6];
    Cact[0].loadFromFile("F:/texture/TestDino/Cact/1.png");
    Cact[1].loadFromFile("F:/texture/TestDino/Cact/2.png");
    Cact[2].loadFromFile("F:/texture/TestDino/Cact/3.png");
    Cact[3].loadFromFile("F:/texture/TestDino/Cact/4.png");
    Cact[4].loadFromFile("F:/texture/TestDino/Cact/5.png");
    Cact[5].loadFromFile("F:/texture/TestDino/Cact/6.png");
    for (int i = 0; i < 6; i++) {
        Cactus[i].setTexture(Cact[i]);
        if (i < 3)
            Cactus[i].setPosition(1000, 395);
        if (i > 2)
            Cactus[i].setPosition(1000, 370);
    }
    srand(NULL(time));
    int cit = rand() % 6 + 1;
    int b = 0, c = 1;
    bool play = false;
    bool gameover = false;
    bool gameover1 = false;
    Texture br;
    br.loadFromFile("F:/texture/TestDino/Bird.png");
    Sprite Bird(br);
    Bird.setTextureRect(IntRect(0, 0, 93, 80));
    int pt = rand() % 2 + 1;
    Bird.setPosition(1000, 380 - 100 * (pt - 1));
    float Fp = 0;
    Clock clock;
    Texture GO;
    GO.loadFromFile("F:/texture/TestDino/GameOver.png");
    Sprite GMOVR(GO);
    GMOVR.scale(0.42, 0.8);
    GMOVR.setPosition(1000, 0);
    Texture BC;
    BC.loadFromFile("F:/texture/TestDino/SpaceRestart.png");
    Sprite BACK(BC);
    BACK.scale(0.42, 0.8);
    BACK.setPosition(1000, 0);
    Texture Nm;
    Nm.loadFromFile("F:/texture/TestDino/Number.png");
    Sprite Number[5];
    float num[5] = { 0, 0, 0, 0, 0 };
    for (int i = 0; i < 5; i++) {
        Number[i].setTexture(Nm);
        Number[i].setTextureRect(IntRect(0, 0, 20, 24));
        Number[i].setPosition(950 - 25 * i, 2);
    }
    Font font;
    Text texti, textC, textH;
    font.loadFromFile("../texture/TestDino/EpilepsySans.ttf");
    texti.setFont(font);
    texti.setCharacterSize(25);
    texti.setFillColor(Color::Black);
    texti.setPosition(300, 180);
    textC.setFont(font);
    textC.setCharacterSize(25);
    textC.setFillColor(Color::Black);
    textC.setPosition(400, 350);
    textH.setFont(font);
    textH.setCharacterSize(25);
    textH.setFillColor(Color::Black);
    textH.setPosition(400, 350);
    while (window.isOpen())
    {
        float time = clock.getElapsedTime().asMicroseconds();
        clock.restart();
        time = time / 800;
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed)
                window.close();
            if (event.type == Event::MouseButtonPressed)
                if (event.key.code == Mouse::Left)
                {
                    Vector2i pos = Mouse::getPosition(window);
                    if (bb.menu)
                    {
                        if (pos.x >= 870 && pos.x <= 900 &&
                            pos.y >= 40 && pos.y <= 70)
                            window.close();
                        if (pos.x >= 830 && pos.x <= 860 &&
                            pos.y >= 40 && pos.y <= 70) {
                            bb.about = true;
                            bb.menu = false;
                            o.back.setPosition(650, 150);
                            texti.setString("Jump the dinosaur up using the space bar! \n GL&HF");
                        }
                        if (pos.x >= 450 && pos.x <= 600 &&
                            pos.y >= 300 && pos.y <= 330) {
                            bb.menu = false;
                            bb.setting = true;
                            o.back.setPosition(650, 150);
                        }
                        if (pos.x >= 470 && pos.x <= 563 &&
                            pos.y >= 250 && pos.y <= 285)
                        {
                            bb.menu = false;
                            bb.start = true;
                        }
                    }
                    else if (bb.setting)
                    {
                        if (pos.x >= 650 && pos.x <= 680 &&
                            pos.y >= 150 && pos.y <= 180)
                        {
                            bb.menu = true;
                            bb.setting = false;
                        }
                        if (pos.x >= 400 && pos.x <= 500 &&
                            pos.y >= 250 && pos.y <= 280)
                        {
                            bb.hard = false;
                            bb.classic = true;
                            c = 1;
                            textC.setString("Difficulty level : Classic");
                        }
                        if (pos.x >= 570 && pos.x <= 650 &&
                            pos.y >= 250 && pos.y <= 280)
                        {
                            c = 0;
                            bb.classic = false;
                            bb.hard = true;
                            c = 2;
                            textH.setString("Difficulty level : Hard");
                        }
                    }
                    else if (bb.start)
                    {
                        if (pos.x >= 80 && pos.x <= 176 &&
                            pos.y >= 40 && pos.y <= 68)
                        {
                            bb.pause = true;
                            Dino.a = 0;
                        }
                    }
                    if (bb.pause)
                    {
                        if (pos.x >= 440 && pos.x <= 580 &&
                            pos.y >= 100 && pos.y <= 130)
                        {
                            bb.pause = false;
                        }
                        else if (pos.x >= 440 && pos.x <= 580 &&
                                 pos.y >= 150 && pos.y <= 180)
                        {
                            bb.menu = true;
                            bb.start = false;
                            bb.setting = false;
                        }
                        if (pos.x >= 450 && pos.x <= 600 &&
                            pos.y >= 300 && pos.y <= 330) 
                        {
                            bb.start = false;
                            bb.menu = false;
                            bb.setting = true;
                            o.back.setPosition(650, 150);
                        }
                    }
                    if (bb.about) 
                    {
                        if (pos.x >= 650 && pos.x <= 680 &&
                            pos.y >= 150 && pos.y <= 180)
                        {
                            bb.menu = true;
                            bb.about = false;
                        }
                    }
                }
            if (Keyboard::isKeyPressed(Keyboard::Escape))
            {
                bb.pause = true;
            }
        }
        if (Keyboard::isKeyPressed(Keyboard::Space))
            if (Dino.onGround && !bb.pause) {
                if (Dino.a < 2) {
                    Dino.dy = -0.5;
                    Dino.onGround = false;
                    Dino.sprite.setTextureRect(IntRect(180, 0, 90, 95));
                    Dino.a = 1;
                }
                else if (Dino.a == 2) {
                    Dino.a = 1;
                    for (int i = 0; i < 6; i++) {
                        if (i < 3)
                            Cactus[i].setPosition(1000, 395);
                        if (i > 2)
                            Cactus[i].setPosition(1000, 370);
                    }
                    cit = rand() % 6 + 1;
                    pt = rand() % 2 + 1;
                    Bird.setPosition(1000, 380 - 100 * (pt - 1));
                    b = 0;
                    GMOVR.setPosition(1000, 0);
                    BACK.setPosition(1000, 0);
                    gameover = false;
                    for (int i = 0; i < 5; i++) {
                        num[i] = 0;
                        Number[i].setTextureRect(IntRect(0, 0, 20, 24));
                    }
                }
            }
        if (Dino.a == 1 && Dino.onGround == true) {
            play = true;
        }
        for (int i = 0; i < 6; i++)
            if (Dino.sprite.getGlobalBounds().intersects(Cactus[i].getGlobalBounds()))
            {
                gameover = true;
            }
        if (Dino.sprite.getGlobalBounds().intersects(Bird.getGlobalBounds()))
        {
            gameover = true;
        }
        if (gameover) {
            Dino.a = 2;
            play = false;
            GMOVR.setPosition(400, 150);
            BACK.setPosition(250, 250);
        }
            if (play && !bb.pause) {
                C.move(-0.3 * time, 0);
                Vector2f Cl = C.getPosition();
                if(Cl.x < -100)
                    C.setPosition(1000, 250);
                if (b < 10) {
                    if (c == 1)
                        Cactus[cit - 1].move(-0.35 * time, 0);
                    if (c == 2)
                        Cactus[cit - 1].move(-0.7 * time, 0);
                    Vector2f ct[6];
                    for (int i = 0; i < 6; i++) {
                        ct[i] = Cactus[i].getPosition();
                        if (ct[i].x < -100) {
                            if (i < 3)
                                Cactus[i].setPosition(1000, 395);
                            if (i > 2)
                                Cactus[i].setPosition(1000, 370);
                            cit = rand() % 6 + 1;
                            b++;
                        }
                    }
                }
                else if (b == 10 && !bb.pause) {
                    if (c == 1)
                        Bird.move(-0.4 * time, 0);
                    if (c == 2)
                        Bird.move(-0.8 * time, 0);
                    Vector2f Br = Bird.getPosition();
                    if (Br.x < -100) {
                        pt = rand() % 2 + 1;
                        Bird.setPosition(1000, 380 - 100 * (pt - 1));
                        b++;
                    }
                }
                else if (b == 11 && !bb.pause) {
                    if (c == 1) {
                        Bird.move(-0.4 * time, 0);
                    }
                    else if (c == 2) {
                        Bird.move(-0.8 * time, 0);
                    }
                    Vector2f Br = Bird.getPosition();
                    if (Br.x < -100) {
                        pt = rand() % 2 + 1;
                        Bird.setPosition(1000, 380 - 100 * (pt - 1));
                        b = 0;
                    }
                }
                num[0] += 0.005;
                if (num[0] > 10) {
                    num[0] -= 10;
                    num[1]++;
                    if (num[1] > 9) {
                        num[1] -= 10;
                        num[2]++;
                        if (num[2] > 9) {
                            num[2] -= 10;
                            num[3]++;
                            if (num[3] > 9) {
                                num[3] -= 10;
                                num[4]++;
                                if (num[4] > 9)
                                    num[4] -= 10;
                                Number[4].setTextureRect(IntRect(20 * int(num[4]), 0, 20, 24));
                            }
                            Number[3].setTextureRect(IntRect(20 * int(num[3]), 0, 20, 24));
                        }
                        Number[2].setTextureRect(IntRect(20 * int(num[2]), 0, 20, 24));
                    }
                    Number[1].setTextureRect(IntRect(20 * int(num[1]), 0, 20, 24));
                }
                Number[0].setTextureRect(IntRect(20 * int(num[0]), 0, 20, 24));
            }
            Fp += 0.0025;
            if (Fp > 2)
                Fp -= 2;
            Bird.setTextureRect(IntRect(93 * int(Fp), 0, 93, 80));
            Dino.update(time);
            window.clear(Color::White);
            if (bb.menu)
            {
                window.draw(o.DinoMenu);
                window.draw(o.game);
                window.draw(o.settings);
                window.draw(o.about);
                window.draw(o.exit);
            }
            if (bb.about)
            {
                window.draw(o.back);
                window.draw(texti);
            }
            if (bb.setting)
            {
                window.draw(o.back);
                window.draw(o.classic);
                window.draw(o.hard);
                window.draw(o.ys);
                if (c == 2)
                    window.draw(textH);
                else
                    window.draw(textC);
            }
            if (bb.start)
            {
                window.draw(Dino.sprite);
                for (int i = 0; i < 6; i++)
                    window.draw(Cactus[i]);
                window.draw(Bird);
                window.draw(o.pause);
                if (bb.pause) {
                    window.draw(o.Continue);
                    window.draw(o.Exit_Text);
                }

                for (int i = 0; i < 5; i++)
                    window.draw(Number[i]);
                window.draw(C);
                window.draw(GMOVR);
                window.draw(BACK);
            }
            window.draw(land);
            window.display();
        }
  return 0;
}